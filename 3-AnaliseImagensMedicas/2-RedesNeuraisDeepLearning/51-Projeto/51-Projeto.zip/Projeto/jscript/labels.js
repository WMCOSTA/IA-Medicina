TARGET_CLASSES = {
  0: "Probabilidade Pessoa Saudável",
  1: "Probabilidade Pessoa Doente"
};
